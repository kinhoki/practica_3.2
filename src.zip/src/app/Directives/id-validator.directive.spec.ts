import { IdValidatorDirective } from './id-validator.directive';

describe('IdValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new IdValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
