import { ProteinValidatorDirective } from './protein-validator.directive';

describe('ProteinValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new ProteinValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
