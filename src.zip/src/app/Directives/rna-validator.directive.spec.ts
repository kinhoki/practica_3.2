import { RnaValidatorDirective } from './rna-validator.directive';

describe('RnaValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new RnaValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
