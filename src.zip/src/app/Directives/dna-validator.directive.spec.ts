import { DnaValidatorDirective } from './dna-validator.directive';

describe('DnaValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new DnaValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
